'use strict';

module.exports = (sequelize, DataTypes) => {
    const comprador = sequelize.define('comprador', {
        apellidos: { type: DataTypes.STRING(150), defaultValue: "" },
        nombres: { type: DataTypes.STRING(150), defaultValue: "" },
        direccion: { type: DataTypes.STRING, defaultValue: "" },
        telefono: { type: DataTypes.STRING(15), defaultValue: "" },
        cedula: { type: DataTypes.STRING(15), defaultValue: "" },
        genero: { type: DataTypes.ENUM(['MASCULINO', 'FEMENINO','OTRO'])},
        external_id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4 }
    }, { timestamps: false, freezeTableName: true });
    //se crea las relaciones entre modelos
    comprador.associate = function (models) {
        //hasMany a varios, hasOne a uno
        comprador.hasOne(models.cuenta, { foreignKey: 'id_comprador', as: 'cuenta' });
    };
    return comprador;
};