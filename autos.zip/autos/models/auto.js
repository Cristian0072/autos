'use strict';

module.exports = (sequelize, DataTypes) => {
    const auto = sequelize.define('auto', {
        marca: { type: DataTypes.STRING(50), allowNull: false },
        modelo: { type: DataTypes.STRING(50), allowNull: false },
        color: { type: DataTypes.ENUM(['ROJO', 'AMARILLO','NEGRO','DORADO','PLATA','AZUL','VERDE','BLANCO'])},
        anio: { type: DataTypes.INTEGER, defaultValue: 0 },
        precio: { type: DataTypes.FLOAT, defaultValue: 0.0 },
        imagen: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },
        estado: { type: DataTypes.BOOLEAN, defaultValue: false },
        external_id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4 }
    }, { freezeTableName: true });
    auto.associate = function (models) {
        auto.hasMany(models.persona, {
            foreignKey: 'id_persona',
            allowNull: false,
        });
    };
    return auto;
};