'use strict';

module.exports = (sequelize, DataTypes) => {
    const venta = sequelize.define('venta', {
        id_auto: { type: DataTypes.INTEGER, allowNull: false },
        id_comprador: { type: DataTypes.INTEGER, allowNull: false },
        estado: { type: DataTypes.BOOLEAN, defaultValue: true },
        fecha_venta: { type: DataTypes.DATEONLY },
        precio_total: { type: DataTypes.FLOAT, defaultValue: 0.0 },
        external_id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4 }
    }, { freezeTableName: true });
    venta.associate = function (models) {
        venta.belongsTo(models.comprador, { foreignKey: 'id_comprador' });
        venta.belongsTo(models.auto, { foreignKey: 'id_auto' });
    }
    return venta;
};