var express = require('express');
var router = express.Router();
let jwt = require('jsonwebtoken');

//llamar al archivo
const personaC = require('../app/controls/PersonaControl');
const autoC = require('../app/controls/AutoControl');
const cuentaC = require('../app/controls/CuentaControl');

let personaControl = new personaC();
let autoControl = new autoC();
let cuentaControl = new cuentaC();

router.get('/', function (req, res, next) {
  res.send('AUTOS');
});

const auth = function middleware(req, res, next) {
  const token = req.headers('TOKEN-KEY');
  if (token === undefined) {
    res.status(400).json({ msg: "ERROR", tag: "Token no existe", code: 400 });
  } else {
    require('dotenv').config();
    //se obtiene la llave
    const key = process.env.KEY;
    //se verifica que token exista y sea valido
    jwt.verify(token, key, async (err, decoded) => {
      if (err) {
        res.status(400).json({ msg: "ERROR", tag: "Token no valido", code: 400 });
      } else {
        const models = require('../app/models');
        const cuenta = models.cuenta;
        //se busca el external
        const aux = await cuenta.findOne({
          where: { external_id: decoded.external }
        });
        if (aux === null) {
          res.status(400).json({ msg: "ERROR", tag: "Token no valido", code: 400 });
        } else {
          //autorizacion
          // Verifica el rol del usuario y autoriza o deniega el acceso
          const rol = aux.persona.rol;

          if (rol === 'GERENTE' || rol === 'VENDEDOR') {
            // Usuario autorizado, sigue con la ejecución
            req.usuario = aux; // Puedes guardar el usuario en el objeto de solicitud para usarlo en las rutas
            next();
          } else {
            // Usuario no autorizado
            res.status(403).json({ msg: 'ERROR', tag: 'Acceso no autorizado', code: 403 });
          }
        }
      }
    });
  }
}
//api de personas
router.get('/admin/personas', auth, personaControl.listar);
router.get('/admin/personas/get/:external', auth, personaControl.obtener);
router.get('/admin/persona/save', auth, personaControl.guardar);
router.put('/admin/personas/editar/:external', auth,personaControl.editar);
//api auto
router.get('/auto', auth,autoControl.listar);
router.get('/auto/get/:external', auth,autoControl.obtener);
router.post('/admin/auto/save', auth,autoControl.guardar);
router.put('/admin/auto/editar/:external', auth,autoControl.editar);
router.post('/admin/auto/file/save', auth,autoControl.guardarFoto);

//api cuenta
router.post('/login', cuentaControl.inicio_sesion);

module.exports = router;
