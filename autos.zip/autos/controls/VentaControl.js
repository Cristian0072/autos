'use strict';
//libreria formidable
var formidable = require('formidable');
var models = require('../models');
var fs = require('fs');

var venta = models.venta;
var extensiones = ['jpg', 'png'];
var tamanioMaximo = 2 * 1024 * 1024;//2 MB

class VentaControl {
    async listar(req, res) {
        var lista = await venta.findAll({
            include: [
                { model: models.auto, as: "auto", attributes: ['marca', 'modelo'] },
                { model: models.comprador, as: "comprador", attributes: ['apellidos', 'nombres'] }
            ],
            attributes: ['id_auto', 'id_comprador', 'fecha_venta', 'precio_total', 'estado']
        });
        res.status(200).json({ msg: "OK", code: 200, datos: lista });
    }

    async obtener(req, res) {
        const external = req.params.external;
        var lista = await venta.findOne({
            where: { external_id: external },
            include: [
                { model: models.auto, as: "auto", attributes: ['marca', 'modelo'] },
                { model: models.comprador, as: "comprador", attributes: ['apellidos', 'nombres'] }
            ],
            attributes: ['id_auto', 'id_comprador', 'fecha_venta', 'precio_total', 'estado']
        });
        if (lista === undefined || lista === null) {
            res.status(200).json({ msg: "OK", code: 200, datos: {} });
        } else {
            res.status(200).json({ msg: "OK", code: 200, datos: lista });
        }
    }

    async guardar(req, res) {
        if (req.body.hasOwnProperty('id_auto') &&
            req.body.hasOwnProperty('id_comprador') &&
            req.body.hasOwnProperty('fecha_venta') &&
            req.body.hasOwnProperty('precio_total') &&
            req.body.hasOwnProperty('estado')) {

            var uuid = require('uuid');
            var data = {
                id_auto: req.body.id_auto,
                id_comprador: req.body.id_comprador,
                fecha_venta: req.body.fecha_venta,
                precio_total: req.body.precio_total,
                external_id: uuid.v4(),
                estado: true
            };
            const result = await venta.create(data);
            //undefined no se define el objeto
            if (!result) {
                res.status(401).json({ msg: "ERROR", tag: "No se puede crear la venta", code: 401 });
            } else {
                res.status(200).json({ msg: "OK", tag: "OK", code: 200 });
            }
        } else {
            res.status(400).json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }
    
    //subir archivos con librería formidable
    async guardarFoto(req, res) {
        //formulario con form
        var form = new formidable.IncomingForm(), files = [];
        //se debe enviar el archivo
        form.on('file', function (field, file) {
            files.push(file);
        }).on('end', function () {
            console.log('OK');
        });

        //parsear funciona de manera asincrona
        form.parse(req, function (err, fields) {
            let listado = files;
            let external = fields.external[0];
            for (let index = 0; index < listado.length; index++) {
                var file = listado[index];
                //validación de tamanio y el tipo de archivo
                var extension = file.originalFilename.split('.').pop().toLowerCase();
                const name = external + '.' + extension;

                if (file.size < tamanioMaximo) {
                    if (extensiones.includes(extension)) {
                        console.log(extension);
                        console.log(name);
                        //guardar en la carpeta multimedia
                        fs.rename(file.filepath, "public/img/" + name, async function (err) {
                            if (err) {
                                res.status(400).json({ msg: "ERROR", tag: "No se pudo guardar la imagen", code: 400 });
                            } else {
                                //buscar venta por external
                                var ventaA = await venta.findOne({ where: { external_id: external } });
                                if (ventaA !== undefined) {
                                    ventaA.archivo = name;
                                    await ventaA.save();
                                    res.status(200).json({ msg: "OK", tag: "Imagen guardado", code: 200 });
                                } else {
                                    res.status(400).json({ msg: "Error", tag: "No se encontro la venta", code: 400 });
                                }
                            }
                        });
                    } else {
                        res.status(400).json({ msg: "ERROR", tag: "Solo soporta " + extensiones, code: 400 });
                    }
                } else {
                    res.status(400).json({ msg: "ERROR", tag: "Archivo demasiado grande, debe ser menor a 2 MB", code: 400 });
                }
            };
        });
    }
}
module.exports = VentaControl;