'use  strict';
var models = require('../models');
var cuenta = models.cuenta;
var persona = models.persona;
let jwt = require('jsonwebtoken');

class CuentaControl {
    async inicio_sesion(req, res) {
        if (req.body.hasOwnProperty('correo') &&
            req.body.hasOwnProperty('clave')) {
            //se busca el correo
            let cuentaA = await cuenta.findOne({
                where: { correo: req.body.correo },
                include: [
                    { model: models.persona, as: "apellidos", attributes: ['apellidos'] },
                    { model: models.persona, as: "nombres", attributes: ['nombres'] }
                ]
            });
            if (cuentaA === null) {
                //cuenta no existe
                res.status(400).json({ msg: "ERROR", tag: "La cuenta no existe", code: 400 });
            } else {
                //estado de la cuenta
                if (cuenta.estado === true) {
                    //valida clave
                    if (cuentaA.clave === req.body.clave) {
                        const token_data = {
                            external: cuentaA.external_id,
                            check: true
                        };
                        require('dotenv').config();
                        //se obtiene la llave
                        const key = process.env.KEY;
                        //se encripta el token_data con los datos de KEY
                        const token = jwt.sign(token_data, key, {
                            //el token expira en tiempo, el cual depende de la aplicación
                            expiresIn: '2h'
                        });
                        var info = {
                            token: token,
                            user: cuentaA.persona.apellidos + ' ' + cuentaA.persona.nombres
                        };
                        res.status(200).json({ msg: "OK", tag: "Bienvenido", code: 200 });
                    } else {
                        res.status(400).json({ msg: "ERROR", tag: "El correo o clave es incorrecta", code: 400 });
                    }
                } else {
                    res.status(400).json({ msg: "ERROR", tag: "La cuenta esta desactivada", code: 400 });
                }
            }
        } else {
            res.status(400).json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }

    async listar(req, res) {
        var lista = await persona.findAll();
        res.status(200);
        res.json({ msg: "OK", code: 200, datos: lista });
    }
    
    async guardar(req, res) {
        if (req.body.hasOwnProperty('nombres') &&
            req.body.hasOwnProperty('apellidos') &&
            req.body.hasOwnProperty('direccion') &&
            req.body.hasOwnProperty('telefono') &&
            req.body.hasOwnProperty('edad') &&
            req.body.hasOwnProperty('rol')&&
            req.body.hasOwnProperty('genero')&&
            req.body.hasOwnProperty('cedula')) {

            var uuid = require('uuid');
            var rolA = await persona.findOne({ where: { external_id: req.body.rol } });
            if (rolA !== undefined) {
                var data = {
                    nombres: req.body.nombres,
                    apellidos: req.body.apellidos,
                    direccion: req.body.direccion,
                    cedula: req.body.cedula,
                    telefono: req.body.telefono,
                    edad: req.body.edad,
                    id_rol: req.body.rol,
                    direccion: req.body.direccion,
                    external_id: uuid.v4()
                }
                var result = await persona.create(data);
                if (result === null) {
                    res.status(401);
                    res.json({ msg: "Error", tag: "No se puede crear", code: 401 });
                } else {
                    //actualiza el external_id
                    rolA.external_id = uuid.v4();
                    await rolA.save();
                    res.status(200);
                    res.json({ msg: "OK", tag: "OK", code: 200 });
                }
            } else {
                res.status(400);
                res.json({ msg: "ERROR", tag: "No existe rol", code: 400 });
            }
        } else {
            res.status(400);
            res.json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }
}

module.exports = PersonaControl;