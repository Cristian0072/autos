"use strict";
//libreria formidable
var formidable = require("formidable");
var models = require("../models");
var fs = require("fs");

var auto = models.auto;
var persona = models.persona;

var extensiones = ["jpg", "png"];
var tamanioMaximo = 2 * 1024 * 1024; //2 MB

class AutoControl {
    async listar(req, res) {
        var lista = await auto.findAll({
            include: [
                {
                    model: models.persona,
                    as: "persona",
                    attributes: ["apellidos", "nombres"],
                },
            ],
            attributes: [
                "marca",
                ["external_id", "id"],
                "modelo",
                "color",
                "anio",
                "precio",
                "imagen",
                "estado",
            ],
        });
        res.status(200).json({ msg: "OK", code: 200, datos: lista });
    }

    async obtener(req, res) {
        const external = req.params.external;
        var lista = await auto.findOne({
            where: { external_id: external },
            include: [
                {
                    model: models.persona,
                    as: "persona",
                    attributes: ["apellidos", "nombres"],
                },
            ],
            attributes: [
                "marca",
                ["external_id", "id"],
                "modelo",
                "color",
                "anio",
                "precio",
                "imagen",
                "estado",
            ],
        });
        if (lista === undefined || lista === null) {
            res.status(200).json({ msg: "OK", code: 200, datos: {} });
        } else {
            res.status(200).json({ msg: "OK", code: 200, datos: lista });
        }
    }

    async guardar(req, res) {
        if (
            req.body.hasOwnProperty("marca") &&
            req.body.hasOwnProperty("modelo") &&
            req.body.hasOwnProperty("color") &&
            req.body.hasOwnProperty("anio") &&
            req.body.hasOwnProperty("precio") &&
            req.body.hasOwnProperty("estado")
        ) {
            var uuid = require("uuid");
            //persona.findOne busca el rol por external_id
            var perA = await persona.findOne({
                where: { external_id: req.body.persona },
                include: [{ model: models.persona, as: "rol", attributes: ["nombre"] }],
            });
            //undefined no define el objeto
            if (perA === undefined || perA === null) {
                res.status(401);
                res.json({ msg: "ERROR", tag: "No se encuentra el editor", code: 401 });
            } else {
                var data = {
                    marca: req.body.marca,
                    modelo: req.body.modelo,
                    color: req.body.color,
                    anio: req.body.anio,
                    precio: req.body.precio,
                    imagen: req.body.imagen,
                    external_id: uuid.v4(),
                    estado: true,
                    id_persona: perA.id,
                };
                if (perA.rol.nombre === "GERENTE") {
                    var result = await auto.create(data);
                    if (result === null) {
                        res.status(401);
                        res.json({ msg: "ERROR", tag: "No se puede crear", code: 401 });
                    } else {
                        //actualizar extenernal
                        perA.external_id = uuid.v4();
                        await perA.save();
                        res.status(200);
                        res.json({ msg: "OK", code: 200 });
                    }
                } else {
                    res.status(400);
                    res.json({
                        msg: "ERROR",
                        tag: "La persona que esta ingresando el auto no es el GERENTE",
                        code: 400,
                    });
                }
            }
        } else {
            res.status(400);
            res.json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }

    async editar(req, res) {
        const external = req.params.external;
        var autoEditar = await auto.findOne({
            where: { external_id: external },
        });
        if (!autoEditar) {
            return res.status(404).json({ msg: "Auto no encontrada", code: 404 });
        }

        if (req.body.hasOwnProperty("marca") &&
            req.body.hasOwnProperty("modelo") &&
            req.body.hasOwnProperty("color") &&
            req.body.hasOwnProperty("anio") &&
            req.body.hasOwnProperty("precio") &&
            req.body.hasOwnProperty("estado")) {
            autoEditar.marca = req.body.marca;
            autoEditar.modelo = req.body.modelo;
            autoEditar.color = req.body.color;
            autoEditar.anio = req.body.anio;
            autoEditar.precio = req.body.precio;
            autoEditar.imagen = req.body.imagen;
            autoEditar.estado = req.body.estado;
            autoEditar.id_comprador = comprador.id;

            var result = await autoEditar.save();

            if (!result) {
                return res.status(500).json({ msg: "Error al editar", code: 500 });
            } else {
                return res.status(200).json({ msg: "Auto editado correctamente", code: 200 });
            }
        } else {
            res.status(400).json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }

    //subir archivos con librería formidable
    async guardarFoto(req, res) {
        //formulario con form
        var form = new formidable.IncomingForm(),
            files = [];
        //se debe enviar el archivo
        form.on("file", function (field, file) {
                files.push(file);
            }).on("end", function () {
                console.log("OK");
            });

        //parsear funciona de manera asincrona
        form.parse(req, function (err, fields) {
            let listado = files;
            let external = fields.external[0];
            for (let index = 0; index < listado.length; index++) {
                var file = listado[index];
                //validación de tamanio y el tipo de archivo
                //se busca la extension
                var extension = file.originalFilename.split(".").pop().toLowerCase();
                const name = external + "." + extension;

                if (file.size < tamanioMaximo) {
                    if (extensiones.includes(extension)) {
                        console.log(extension);
                        console.log(name);
                        //guardar en la carpeta img
                        fs.rename(file.filepath,"public/img/" + name, async function (err) {
                                if (err) {
                                    res.status(400).json({
                                        msg: "ERROR",
                                        tag: "No se pudo guardar la imagen",
                                        code: 400,
                                    });
                                } else {
                                    //buscar auto por external
                                    var autoA = await auto.findOne({
                                        where: { external_id: external },
                                    });
                                    if (autoA !== undefined) {
                                        autoA.archivo = name;
                                        await autoA.save();
                                        res.status(200).json({ msg: "OK", tag: "Archivo guardado", code: 200 });
                                    } else {
                                        res.status(400).json({ msg: "Error", tag: "No se encontro el auto", code: 400 });
                                    }
                                }
                            }
                        );
                    } else {
                        res.status(400).json({ msg: "ERROR",tag: "Solo soporta " + extensiones, code: 400 });
                    }
                } else {
                    res.status(400).json({ msg: "ERROR", tag: "Archivo demasiado grande, debe ser menor a 2 MB", code:400 });                             
                }
            }
        });
    }
}
module.exports = AutoControl;
