'use  strict';
var models = require('../models');
var persona = models.persona;

class PersonaControl {
    async listar(req, res) {
        var lista = await persona.findAll({
            include: [
                { model: models.cuenta, as: "cuenta", attributes: ['correo'] },
            ],
            attributes: ['apellidos', ['external_id', 'id'], 'nombres', 'direccion', 'cedula', 'telefono', 'edad', 'genero', 'rol']
        });
        res.status(200);
        res.json({ msg: "OK", code: 200, datos: lista });
    }

    async obtener(req, res) {
        const external = req.params.external;
        var lista = await persona.findOne({
            where: { external_id: external },
            include: [
                { model: models.cuenta, as: "cuenta", attributes: ['correo'] }
            ],
            attributes: ['apellidos', ['external_id', 'id'], 'nombres', 'direccion', 'cedula', 'telefono', 'edad', 'genero', 'rol']
        });
        if (lista === undefined || lista === null) {
            res.status(404).json({ msg: "Persona no encontrada", code: 404 });
        } else {
            res.status(200).json({ msg: "OK", code: 200, datos: lista });
        }
    }

    async guardar(req, res) {
        if (eq.body.hasOwnProperty('nombres') &&
            req.body.hasOwnProperty('apellidos') &&
            req.body.hasOwnProperty('direccion') &&
            req.body.hasOwnProperty('telefono') &&
            req.body.hasOwnProperty('edad') &&
            req.body.hasOwnProperty('genero') &&
            req.body.hasOwnProperty('rol') &&
            req.body.hasOwnProperty('clave') &&
            req.body.hasOwnProperty('correo')) {

            var uuid = require('uuid');
            var data = {
                nombres: req.body.nombres,
                apellidos: req.body.apellidos,
                direccion: req.body.direccion,
                telefono: req.body.telefono,
                edad: req.body.edad,
                genero: req.body.genero,
                rol: req.body.rol,
                cuenta: {
                    correo: req.body.correo,
                    clave: req.body.clave
                },
                external_id: uuid.v4()
            };
            //permite realizar el rollback "transaction"
            let transaction = await models.sequelize.transaction();
            try {
                var result = await persona.create(data, { include: [{ model: models.cuenta, as: "cuenta" }], transaction });
                await transaction.commit();
                if (result === null) {
                    res.status(401).json({ msg: "Error", tag: "No se puede crear", code: 401 });
                } else {
                    //actualiza el external_id
                    rolA.external_id = uuid.v4();
                    await rolA.save();
                    res.status(200).json({ msg: "OK", code: 200 });
                }
            } catch (error) {
                if (transaction) await transaction.rollback();
                res.status(203).json({ msg: "Error", error_msg: error, code: 203 });
            }
        } else {
            res.status(400).json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }

    async editar(req, res) {
        const external = req.params.external;

        var personaEditar = await persona.findOne({
            where: { external_id: external }
        });

        if (!personaEditar) {
            return res.status(404).json({ msg: "Persona no encontrada", code: 404 });
        }

        if (req.body.hasOwnProperty('nombres') &&
            req.body.hasOwnProperty('apellidos') &&
            req.body.hasOwnProperty('direccion') &&
            req.body.hasOwnProperty('telefono') &&
            req.body.hasOwnProperty('edad') &&
            req.body.hasOwnProperty('rol') &&
            req.body.hasOwnProperty('clave')) {

            let transaction = await models.sequelize.transaction();

            try {
                personaEditar.apellidos = req.body.apellidos;
                personaEditar.nombres = req.body.nombres;
                personaEditar.direccion = req.body.direccion;
                personaEditar.telefono = req.body.telefono;
                personaEditar.edad = req.body.edad;
                personaEditar.clave = req.body.clave;
                personaEditar.rol = req.body.rol;

                var result = await personaEditar.save({ transaction });

                if (!result) {
                    await transaction.rollback();
                    return res.status(401).json({ msg: "Error al editar persona", code: 401 });
                } else {
                    personaEditar.external_id = uuid.v4();
                    await transaction.commit();
                    return res.status(200).json({ msg: "Persona actualizada", code: 200 });
                }
            } catch (error) {
                await transaction.rollback();
                return res.status(401).json({ msg: "Error al editar persona", code: 401 });
            } 
        } else {
            return res.status(400).json({ msg: "ERROR", tag: "Faltan datos", code: 400 });
        }
    }
}
module.exports = PersonaControl;